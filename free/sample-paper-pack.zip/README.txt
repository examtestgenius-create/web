StudyHub Sample Pack

This mini pack shows the style of bundled papers and memos. Replace these files with real samples any time.
